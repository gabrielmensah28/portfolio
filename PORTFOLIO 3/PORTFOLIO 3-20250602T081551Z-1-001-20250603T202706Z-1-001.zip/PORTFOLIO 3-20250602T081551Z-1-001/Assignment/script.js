
// 1. Create an object construction function
function Student(name, age) {
  this.name = name;
  this.age = age;
}

// 2. Create a new object in the object construction function
let student1 = new Student("John Doe", 20);

// 3. Add a new property
student1.major = "Computer Science";

// 4. Add a new method to the already created object
student1.displayInfo = function() {
  console.log(`Name: ${this.name}, Age: ${this.age}, Major: ${this.major}`);
}

// 5. Add a method to the constructor function
Student.prototype.updateAge = function(newAge) {
  this.age = newAge;
}

